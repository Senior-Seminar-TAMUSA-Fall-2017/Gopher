/*
 * GThread.java
 * Created by Arlen McDonald 9/3/17
 * 
 * This program is a helper class for GCrawler.
 */
package gcrawler;

import java.io.BufferedInputStream;
import java.io.DataOutputStream;
import java.io.FileWriter;
import java.net.Socket;
import java.util.ArrayList;
import java.util.Scanner;

public class GThread implements Runnable{
    
    // Variable Declarations
    private String URL;
    private Integer port;
    private Boolean debug = false;  // Debug mode dumps the raw data into the files, true to enable, does not crawl found links.
    private Integer depth = 0;  // How many links deep you have travelled.
    private Integer maxDepth = 50;  // Limit crawling depth.
    
    // Create command Queue
    ArrayList<String> comQueue = new ArrayList();
    
    public GThread(String URLIn, Integer portIn){  // Constructor for GThread
        URL = URLIn;
        port = portIn;
    }

    @Override
    public void run(){  // Everything you want the thread to do has to start here.
        
        comQueue.add("\r\n");  // Root command - Display main menu - Will run once per site.
        
        try{  // For both network and file actions, for now.
            
            // Create a file - Name is the URL without the periods.
            FileWriter wr = new FileWriter(URL.replace(".","")+".csv");
            
            // Loop while there are commands in the queue and not at max.
            while(comQueue.size() > depth && depth < maxDepth){
                
                // Create a socket - This is connection oriented, disconnects when all its data is delivered.
                Socket gopher = new Socket(URL, port);

                // Create a scanner for the input stream from the server
                Scanner inPut = new Scanner(new BufferedInputStream(gopher.getInputStream()));

                // Create an output stream to send data to the server
                DataOutputStream outPut = new DataOutputStream(gopher.getOutputStream());

                // Show the user what is happening 
                if(comQueue.get(depth)=="\r\n") System.out.println("Crawling Site: " + URL);
                else System.out.print("Crawling Link: " +URL +" " + comQueue.get(depth));
                
                // Send data out
                outPut.writeBytes(comQueue.get(depth));

                // Get data back
                while(inPut.hasNextLine()){
                    wr.append(ParseMenu(inPut.nextLine(), debug));  // Parse raw input and save results.
                }
                
                depth++;
            }
            
            // Done with the file
            wr.close();  
            
            System.out.println("Exiting Site: " + URL);  // Finishing up
        }
        catch (Exception ex){  // I know I need to break this down a lot more, but for now...
            System.out.println(ex.toString());
        }
    }
    
    // A method to parse the data returned from the gopher into csv format so it can be saved in a file.
    private String ParseMenu(String str, Boolean debug){
        
        // Variable declarations
        String header = "\"" + URL + "\",\"" + port + "\",\"" + comQueue.get(depth).substring(0, comQueue.get(depth).length()-2) + "\",\"";
        String text1; // Generic variables to hold strings.
        String text2;
        
        Scanner token = new Scanner(str);  // Instance scanner object.
        token.useDelimiter("\t");  // Menu items are tab delimited.
        
        if(debug) return str + "\n";  // If in debug mode, return raw text, does not crawl.
        else{  // Parse the data received from the gopher.
            if(str.equals(".")) return header + ".\",\""+"Full Stop Received\"\n"; // Check for Full Stop - end of data
            
            else{  // Select different cannonical data types.
                
                // Text file
                if(str.startsWith("0") && str.contains("\t")){
                    return header+"0\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Submenu (Gopher)
                else if(str.startsWith("1") && str.contains("\t")){
                    text1 = token.next().substring(1);
                    text2 = token.next();
                    if(text2.startsWith("/")){  // Check if it is a valid command.
                        // Grab link and add it to the command queue, if it is not already there, prevents loops.
                        if(!comQueue.contains(text2+"\r\n")) comQueue.add(text2 + "\r\n");
                    }
                    return header + "1\",\"" + text1 + "\",\"" + text2 + "\"\n";
                }
                
                // CCSO nameserver
                else if(str.startsWith("2") && str.contains("\t")){
                    return header + "2\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Error response from server
                else if(str.startsWith("3") && str.contains("\t")){
                    return header + "3\",\"" + token.next().substring(1)+ "\"\n";
                }
                
                // BinHex file (Old Mac stuff)
                else if(str.startsWith("4") && str.contains("\t")){
                    return header + "4\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // DOS format file
                else if(str.startsWith("5") && str.contains("\t")){
                    return header + "5\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // UUEncoded file
                else if(str.startsWith("6") && str.contains("\t")){
                    return header + "6\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Search engine (Archie?)
                else if(str.startsWith("7") && str.contains("\t")){
                    return header + "7\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Telnet
                else if(str.startsWith("8") && str.contains("\t")){
                    return header + "8\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Binary file
                else if(str.startsWith("9") && str.contains("\t")){
                    return header + "9\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Mirrored Server
                else if(str.startsWith("+") && str.contains("\t")){
                    return header + "+\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // GIF file
                else if(str.startsWith("g") && str.contains("\t")){
                    return header + "g\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Image file
                else if(str.startsWith("I") && str.contains("\t")){
                    return header + "I\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Telnet 3270 (Old IBM stuff)
                else if(str.startsWith("T") && str.contains("\t")){
                    return header + "T\"v" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
            
                
                // Non-cannonical types - Not in the spec but recognized everywhere.
                
                // HTML
                else if(str.startsWith("h") && str.contains("\t")){
                    return header + "h\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
                
                // Informational Message
                else if(str.startsWith("i")&& str.contains("\t")){
                    return header + "i\",\"" + token.next().substring(1,str.indexOf("\t"))+ "\"\n";
                }
                
                // Sound file
                else if(str.startsWith("s") && str.contains("\t")){
                    return header + "s\",\"" + token.next().substring(1) + "\",\"" + token.next()+ "\"\n";
                }
            }
        }
        return "";  // Only malformed packets should get here, discard them.
    }
}
