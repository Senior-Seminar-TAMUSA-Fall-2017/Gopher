/*************************************
 * Gopher.java
 *
 * This is a small proof-of-concept
 * program for creating a gopher client in java.
 * 
 * Remote commands displayed in magenta 
 * probably won't work.  
 * Item types that should work are; 
 * 0, 1, 2, 3, 4, 6, 7, +, and i
 * 
 * Usage should be pretty self explanatory.
 * When in doubt try MENU, only gopher URLs
 * enclosed in quotes are supported.
 * 
 * URLs to try "gopher.floodgap.com"
 *             "pollett.org"
 *             "gopher.superglobalmegacorp.com"
 * 
 * For information about Gopher;
 * https://en.wikipedia.org/wiki/Gopher_(protocol)
 *
 * Author - Arlen McDonald
 * Created - 6/24/17
 *
 ************************************/
package gopher;

import java.io.*;
import java.net.*;
import java.util.Scanner;

public class Gopher {

    public static void main(String[] args) {
        
        // Variable declarations
        Boolean debug = false;  // Set to true if you want all menu data displayed.
        //Boolean debug = true;
        Boolean done = false;
        String URL = "gopher.floodgap.com";  // Default gopher server
        //String curGopher = "pollett.org";  // Default gopher server
        Integer port = 70;  // Default port
        String command;  // Requested action - from user
        
        // Main loop
        while(!done){ 
            command = UserMenu(URL, port); // Display menu and get user response
            if(command.equals("quit") || command.equals("QUIT") || command.equals("Quit")) done = true;  // Look for done
            else{  // Action other than quit
                if(command.startsWith("\"")){  // Look for URL change
                    URL = command.substring(1, command.length() - 1);
                    command = "\r\n";  // Go ahead and display the menu
                }
                try{  // Network actions
                    
                    // Create a socket
                    Socket gopher = new Socket(URL, port);

                    // Create an scanner for the input stream from the server
                    Scanner inPut = new Scanner(new BufferedInputStream(gopher.getInputStream()));

                    // Create an output stream to send data to the server
                    DataOutputStream outPut = new DataOutputStream(gopher.getOutputStream());

                    // Send data out
                    if(command.equals("menu") || command.equals("MENU") || command.equals("Menu")) outPut.writeBytes("\r\n");
                    else outPut.writeBytes(command + "\r\n");

                    // Get data back
                    while(inPut.hasNextLine()){
                        GopherMenu(inPut.nextLine(), debug);  // Parse and display received data.
                    }
                }
                catch (IOException ex) {  // Any I/O error.
                    System.out.println(ex.toString());
                } 
            }
        }
    }
    
    // A local menu to get a response from user.
    static String UserMenu(String url, Integer port){
        Scanner inp = new Scanner(System.in);  // Instance scanner object.
        // Prompt the user and get input
        System.out.println();
        System.out.println("MENU displays the remote menu, remote commands start with /, urls in quotes \"\", QUIT exits.");
        System.out.println("Current Gopher is " + url + " on port " + port);
        System.out.print("Enter a command: ");
        return inp.next();  // Return user input.
    }
    
    // Parse the data returned from the gopher and display it as a nice menu.
    static void GopherMenu(String str, Boolean debug){
        
        // Macros to change console colors - These should only work in console...
        String ANSI_RESET = "\u001B[0m";
        String ANSI_BLACK = "\u001B[30m";
        String ANSI_RED = "\u001B[31m";
        String ANSI_GREEN = "\u001B[32m";
        String ANSI_YELLOW = "\u001B[33m";
        String ANSI_BLUE = "\u001B[34m";
        String ANSI_MAGENTA = "\u001B[35m";
        String ANSI_CYAN = "\u001B[36m";
        String ANSI_WHITE = "\u001B[37m";

        Scanner token = new Scanner(str);  // Instance scanner object.
        token.useDelimiter("\t");  // Menu items are tab delimited.
        
        if(debug){
            if(str.equals(".")) System.out.println("Full Stop Received");
            else System.out.println(str);  // Print raw text
        }
        else{  // Parse the data received from the gopher.
        
            if(!str.equals(".")){  // Check for Full Stop - end of data
                // Select different cannonical data types.
                if(str.startsWith("0") && str.contains("\t")){  // Text file
                    System.out.println(token.next().substring(1) + ANSI_BLUE + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("1") && str.contains("\t")){  // Submenu (Gopher)
                    System.out.println(token.next().substring(1) + ANSI_GREEN + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("2") && str.contains("\t")){  // CCSO nameserver (This should work if I can find one to test...)
                    System.out.println(token.next().substring(1) + ANSI_CYAN + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("3") && str.contains("\t")){  // Error response from server
                    System.out.println(ANSI_RED + token.next().substring(1) + ANSI_RESET);
                }
                else if(str.startsWith("4") && str.contains("\t")){  // BinHex file (Old Mac stuff) (This should work if I can find one to test...)
                    System.out.println(token.next().substring(1) + ANSI_CYAN + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("5") && str.contains("\t")){  // DOS format file
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("6") && str.contains("\t")){  // UUEncoded file (This should work if I can find one to test...)
                    System.out.println(token.next().substring(1) + ANSI_CYAN + "\t" + token.next() + ANSI_RESET);
                }   
                else if(str.startsWith("7") && str.contains("\t")){  // Search engine (Archie?)
                    System.out.println(token.next().substring(1) + ANSI_CYAN + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("8") && str.contains("\t")){  // Telnet
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("9") && str.contains("\t")){  // Binary file (What type?)
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("+") && str.contains("\t")){  // Mirrored Server
                    System.out.println(token.next().substring(1) + ANSI_CYAN + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("g") && str.contains("\t")){  // GIF file
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("I") && str.contains("\t")){  // Image file (What type?)
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("T") && str.contains("\t")){  // Telnet 3270 (Old IBM stuff)
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                // Non-cannonical types - Not in the spec but recognized everywhere.
                else if(str.startsWith("h") && str.contains("\t")){  // HTML
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else if(str.startsWith("i")&& str.contains("\t")){  // Informational Message
                    System.out.println(token.next().substring(1,str.indexOf("\t")));
                }
                else if(str.startsWith("s") && str.contains("\t")){  // Sound file (What type?)
                    System.out.println(token.next().substring(1) + ANSI_MAGENTA + "\t" + token.next() + ANSI_RESET);
                }
                else System.out.println(str);  // All else - plain text and malformed menu items should be handled here.
            }
        }
    }
}